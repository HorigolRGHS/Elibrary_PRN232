"use client";

import React, { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { CategoryService } from "@/services/category/Category";
import { CategoryReadDTO } from "@/models/dtos/categoryDTO";
import { getAuthToken } from '@/api/apiClient';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default function CategoryDetailPage() {
  const params = useParams() as { id?: string };
  const id = params?.id ? Number(params.id) : null;
  const router = useRouter();

  const [category, setCategory] = useState<CategoryReadDTO | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    const fetch = async () => {
      try {
        setLoading(true);

        // if current user is Admin, prefer the admin per-item endpoint which uses admin/(${id})
        let data: CategoryReadDTO | null = null;
        const token = getAuthToken();
        if (token) {
          try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            const roles = payload?.roles ?? payload?.role ?? payload?.["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
            const isAdmin = Array.isArray(roles) ? roles.includes('Admin') : roles === 'Admin';
            if (isAdmin) {
              data = await CategoryService.getAdminItem(id);
            }
          } catch (e) {
            // ignore token parse errors and fall back to public get
          }
        }

        if (!data) {
          data = await CategoryService.getById(id);
        }

        setCategory(data);
        setName(data.categoryName);
        setDescription((data as any).description || "");
      } catch (err) {
        console.error(err);
        alert("Unable to load category");
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id]);

  if (!id) return <div className="p-6">Category ID not found.</div>;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return alert("Category name cannot be empty");
    try {
      setSaving(true);
      await CategoryService.updateCategory(id, { CategoryName: name.trim(), Description: description.trim() });
      router.push("/dashboard/categories");
      router.refresh();
    } catch (err) {
      console.error("Update failed:", err);
      alert("Update failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Category details</CardTitle>
            <CardDescription>Edit a category's properties.</CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          {loading ? (
            <div>Loading...</div>
          ) : category ? (
            <form onSubmit={handleSave} className="grid gap-4 max-w-md">
              <div>
                <label className="block text-sm font-medium mb-1">ID</label>
                <div className="p-2 bg-muted/10 rounded">{category.categoryId}</div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Category name</label>
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} />
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={saving}>
                  {saving ? "Saving..." : "Save"}
                </Button>
                <Button variant="outline" type="button" onClick={() => router.back()}>
                  Cancel
                </Button>
              </div>
            </form>
          ) : (
            <div>Category not found.</div>
          )}
        </CardContent>

        <CardFooter />
      </Card>
    </div>
  );
}
