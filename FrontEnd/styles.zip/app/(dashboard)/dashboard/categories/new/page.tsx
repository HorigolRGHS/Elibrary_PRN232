"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { CategoryService } from "@/services/category/Category";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default function NewCategoryPage() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return alert("Category name cannot be empty");
    try {
      setLoading(true);
      await CategoryService.createCategory({ CategoryName: name.trim(), Description: description.trim() });
      router.push("/dashboard/categories");
      router.refresh();
    } catch (err) {
      console.error("Create failed:", err);
      alert("Create category failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Create category</CardTitle>
            <CardDescription>Provide a name and optional description.</CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Category name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Category name" />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} placeholder="Description (optional)" />
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={loading}>
                {loading ? "Saving..." : "Create"}
              </Button>
              <Button variant="outline" type="button" onClick={() => router.back()}>
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>

        <CardFooter />
      </Card>
    </div>
  );
}
