"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useCategories } from "@/hooks/useCategories";
import { CategoryService } from "@/services/category/Category";
import { useRouter } from "next/navigation";
import { getAuthToken } from "@/api/apiClient";
import { Card, CardHeader, CardTitle, CardDescription, CardAction, CardContent, CardFooter } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

export default function Page() {
  const { categories, loading, error, refresh } = useCategories();
  const router = useRouter();
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmTarget, setConfirmTarget] = useState<number | null>(null);
  const [diagError, setDiagError] = useState<any>(null);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const token = getAuthToken();
    if (!token) return setIsAdmin(false);
    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      const roles = payload?.roles ?? payload?.role ?? payload?.["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
      if (Array.isArray(roles)) {
        setIsAdmin(roles.includes("Admin"));
      } else {
        setIsAdmin(roles === "Admin");
      }
    } catch (e) {
      setIsAdmin(false);
    }
  }, []);

  // NOTE: removed backend OPTIONS probing that previously checked Allow header. We now rely on
  // admin role checks and handle errors from actual DELETE/PUT attempts.

  const openDeleteConfirm = (id: number) => {
    if (!isAdmin) {
      alert("You need Admin privileges to delete categories.");
      return;
    }
    setConfirmTarget(id);
    setDiagError(null);
    setConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    const id = confirmTarget;
    if (!id) return;
    setDeletingId(id);
    try {
      await CategoryService.deleteCategory(id);
      setConfirmOpen(false);
      // refresh the client-side categories list
      try {
        await refresh();
      } catch (e) {
        // fallback to router refresh if needed
        router.refresh();
      }
    } catch (err: any) {
      console.error('Delete failed:', err);
      // prepare diagnostics for copy/share
      const payload = {
        message: err?.message || 'Delete failed',
        status: err?.status ?? err?.response?.status,
        attempted: err?.attempted ?? err?.config?.url,
        responseHeaders: err?.responseHeaders ?? err?.response?.headers,
        responseData: err?.responseData ?? err?.response?.data,
        cause: err?.cause ?? undefined,
      };
      setDiagError(payload);
    } finally {
      setDeletingId(null);
    }
  };

  const copyDiagnostics = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(diagError, null, 2));
      alert('Diagnostics copied to clipboard');
    } catch (e) {
      alert('Could not copy diagnostics: ' + String(e));
    }
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return categories;
    return categories.filter((c) => `${c.categoryName}`.toLowerCase().includes(q) || `${c.categoryId}`.includes(q));
  }, [categories, query]);

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div>
            <CardTitle>Categories</CardTitle>
            <CardDescription>Manage categories used to classify documents.</CardDescription>
          </div>
          <CardAction>
            <Button asChild>
              <Link href="/dashboard/categories/new">Create category</Link>
            </Button>
          </CardAction>
        </CardHeader>

        <CardContent>
          <div className="mb-4 flex gap-3">
            <Input placeholder="Search by name or id" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>

          {loading ? (
            <div>Loading...</div>
          ) : error ? (
            <div className="text-destructive">Error loading categories: {error}</div>
          ) : filtered.length === 0 ? (
            <div>No categories found.</div>
          ) : (
            <Table>
              <TableHeader>
                <tr>
                  <TableHead className="w-24">ID</TableHead>
                  <TableHead>Category name</TableHead>
                  <TableHead className="w-48">Actions</TableHead>
                </tr>
              </TableHeader>
              <TableBody>
                {filtered.map((c, idx) => (
                  <TableRow key={`${c.categoryId ?? "cat"}-${idx}`}>
                    <TableCell>{c.categoryId}</TableCell>
                    <TableCell>{c.categoryName}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/dashboard/categories/${c.categoryId}`}>View / Edit</Link>
                        </Button>
                        {isAdmin ? (
                          <>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => openDeleteConfirm(c.categoryId)}
                              disabled={deletingId === c.categoryId}
                            >
                              {deletingId === c.categoryId ? "Deleting..." : "Delete"}
                            </Button>
                          </>
                        ) : (
                          <Button variant="ghost" size="sm" disabled title="Admin role required to delete">
                            Delete
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
        {/* Confirmation / diagnostics dialog */}
        <Dialog open={confirmOpen} onOpenChange={(v) => { setConfirmOpen(v); if (!v) { setDiagError(null); setConfirmTarget(null); } }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm delete</DialogTitle>
              <DialogDescription>Are you sure you want to delete category ID {confirmTarget}? This action cannot be undone.</DialogDescription>
            </DialogHeader>

            {diagError ? (
              <div className="mt-4">
                <div className="text-sm font-medium text-destructive">Delete failed</div>
                <pre className="mt-2 max-h-40 overflow-auto rounded border p-2 text-xs bg-muted">{JSON.stringify(diagError, null, 2)}</pre>
                <div className="mt-3 flex gap-2">
                  <Button onClick={copyDiagnostics} size="sm">Copy diagnostics</Button>
                  <Button variant="ghost" size="sm" onClick={() => { setDiagError(null); setConfirmOpen(false); }}>Close</Button>
                </div>
              </div>
            ) : (
              <DialogFooter>
                <div className="flex gap-2">
                  <Button variant="destructive" onClick={handleConfirmDelete} disabled={deletingId !== null}>{deletingId ? 'Deleting...' : 'Delete'}</Button>
                  <Button variant="ghost" onClick={() => setConfirmOpen(false)}>Cancel</Button>
                </div>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>

        <CardFooter>
          <div className="flex items-center justify-between w-full">
            <div className="text-sm text-muted-foreground">Total: {categories.length}</div>
            <div />
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
