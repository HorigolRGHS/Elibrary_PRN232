"use client";

import { useEffect, useState } from "react";
import { Calendar, Eye, Download, FileText, Edit, Trash2 } from "lucide-react";
import { toast } from "react-toastify";

import { DocumentUserResponseItemDTO } from "@/models/dtos/documentDTO";

import PDFReader from "@/components/ui/pdf-reader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Badge from "@/components/ui/badge";
import { DocumentService } from "@/services/document/Document";
import { EditDocumentDialog } from "@/components/documents/EditDocumentDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useCurrentUserId } from "@/hooks/useCurrentUserId";
import { useRouter } from "next/navigation";

interface DocumentPageProps {
    params: { id: string };
}

const triggerFileDownload = (file: File, fallbackName: string): void => {
    const url = URL.createObjectURL(file);
    const link = window.document.createElement('a');
    link.href = url;
    link.download = file.name || fallbackName;
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

export default function DocumentPage({ params }: DocumentPageProps) {
    const router = useRouter();
    const currentUserId = useCurrentUserId();
    const [document, setDocument] = useState<DocumentUserResponseItemDTO | null>(null);
    const [documentStream, setDocumentStream] = useState<File | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const docId = parseInt(params.id);
    const isCreator = document && currentUserId && document.createdBy === currentUserId;


    useEffect(() => {
        const fetchDocumentData = async () => {
            try {
                setLoading(true);
                setError(null);

                const doc = await DocumentService.getUserDocumentDetails(docId);
                setDocument(doc);

                if (doc.fileUrl) {
                    const stream = await DocumentService.getDocumentStream(docId, doc.fileUrl, "preview");
                    setDocumentStream(stream);
                }
            } catch (err) {
                console.error('Error fetching document:', err);
                setError('Failed to load document');
            } finally {
                setLoading(false);
            }
        };

        fetchDocumentData();
    }, [docId]);

    const handleDownload = async () => {
        if (!document?.fileUrl) return;

        try {
            const file = await DocumentService.downloadDocument(docId, document.fileUrl);
            triggerFileDownload(file, `${document.title}.pdf`);
        } catch (err) {
            console.error('Error downloading document:', err);
            setError('Failed to download document');
        }
    };

    const handlePDFLoadError = (error: Error) => {
        console.error('PDF load error:', error);
        setError('Failed to load PDF viewer');
    };

    const handleDelete = async () => {
        setIsDeleting(true);
        try {
            await DocumentService.deleteDocument(docId);
            toast.success("Document deleted successfully!");
            router.push("/");
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "Failed to delete document";
            toast.error(errorMessage);
        } finally {
            setIsDeleting(false);
            setIsDeleteDialogOpen(false);
        }
    };

    if (loading) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="animate-pulse space-y-6">
                    <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-96 bg-gray-200 rounded"></div>
                </div>
            </div>
        );
    }

    if (error || !document) {
        return (
            <div className="container mx-auto px-4 py-8">
                <Card className="text-center">
                    <CardContent className="pt-6">
                        <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                            {error || 'Document not found'}
                        </h3>
                        <p className="text-gray-500">
                            The document you&apos;re looking for doesn&apos;t exist or couldn&apos;t be loaded.
                        </p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8 space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-start justify-between">
                        <div className="space-y-2">
                            <CardTitle className="text-2xl font-bold">{document.title}</CardTitle>
                            <CardDescription className="text-base">
                                {document.description}
                            </CardDescription>
                        </div>
                        <div className="flex gap-2 flex-wrap justify-end">
                            <Button
                                onClick={handleDownload}
                                className="flex items-center gap-2"
                                disabled={!document.fileUrl}
                            >
                                <Download className="w-4 h-4" />
                                Download
                            </Button>
                            
                            {/* Edit & Delete buttons for creator */}
                            {isCreator && (
                                <>
                                    <Button
                                        onClick={() => setIsEditDialogOpen(true)}
                                        variant="outline"
                                        className="flex items-center gap-2"
                                    >
                                        <Edit className="w-4 h-4" />
                                        Edit
                                    </Button>
                                    <Button
                                        onClick={() => setIsDeleteDialogOpen(true)}
                                        variant="destructive"
                                        className="flex items-center gap-2"
                                    >
                                        <Trash2 className="w-4 h-4" />
                                        Delete
                                    </Button>
                                </>
                            )}
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 pt-4">
                        <Badge variant="default" className="flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            {document.categoryName}
                        </Badge>
                        <Badge variant="outline" className="flex items-center gap-1">
                            {document.subjectName}
                        </Badge>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                                <Eye className="w-4 h-4" />
                                {document.viewCount} views
                            </span>
                            <span className="flex items-center gap-1">
                                <Download className="w-4 h-4" />
                                {document.downloadCount} downloads
                            </span>
                            <span className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {new Date(document.createdDate).toLocaleDateString()}
                            </span>
                        </div>
                    </div>
                </CardHeader>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Document Viewer</CardTitle>
                    <CardDescription>
                        View the document content below. Use the controls to navigate, zoom, and interact with the PDF.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {documentStream ? (
                        <PDFReader
                            file={documentStream}
                            height="600px"
                            onLoadError={handlePDFLoadError}
                            enableDownload={true}
                            enableRotate={true}
                            enableZoom={true}
                            className="w-full"
                        />
                    ) : (
                        <div className="h-[600px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                            <div className="text-center">
                                <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                                <p className="text-gray-600">No PDF file available for this document</p>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Edit Document Dialog */}
            <EditDocumentDialog
                isOpen={isEditDialogOpen}
                document={document}
                onClose={() => setIsEditDialogOpen(false)}
                onSuccess={() => {
                    // Refresh document data
                    const refetch = async () => {
                        const doc = await DocumentService.getUserDocumentDetails(docId);
                        setDocument(doc);
                    };
                    refetch();
                }}
            />

            {/* Delete Document Dialog */}
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Delete Document</AlertDialogTitle>
                        <AlertDialogDescription>
                            Are you sure you want to delete &quot;{document?.title}&quot;? This action cannot be undone.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="flex gap-3 justify-end">
                        <AlertDialogCancel disabled={isDeleting}>
                            Cancel
                        </AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleDelete}
                            disabled={isDeleting}
                            className="bg-destructive hover:bg-destructive/90"
                        >
                            Delete
                        </AlertDialogAction>
                    </div>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}