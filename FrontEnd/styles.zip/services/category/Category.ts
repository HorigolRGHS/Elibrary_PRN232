import { api } from "@/api/apiClient";
import apiClient from "@/api/apiClient";
import buildQuery from "odata-query";
import { CategorySelect, CategoryReadDTO } from "@/models/dtos/categoryDTO";

const toSelect = (item: any): CategorySelect => {
    return {
        categoryId: item.categoryId ?? item.CategoryId ?? item.id ?? 0,
        categoryName: item.categoryName ?? item.CategoryName ?? item.Name ?? "",
    };
};

const toRead = (item: any): CategoryReadDTO => {
    return {
        categoryId: item.categoryId ?? item.CategoryId ?? item.id ?? 0,
        categoryName: item.categoryName ?? item.CategoryName ?? item.Name ?? "",
        description: item.description ?? item.Description ?? undefined,
        createdDate: item.createdDate ?? item.CreatedDate ?? (item.createdAt ?? ""),
        updatedDate: item.updatedDate ?? item.UpdatedDate ?? (item.updatedAt ?? ""),
    };
};

export const CategoryService = {
    // NOTE: removed OPTIONS preflight probing (supportsItemMethods) to avoid triggering server OPTIONS
    // The frontend will rely on admin role checks and handle failures from actual PUT/DELETE requests.
    getSelectCategories: async (): Promise<CategorySelect[]> => {
        const data = await api.get<any[]>(`/catalog/api/categories`);
        return (data || []).map(toSelect);
    },

    // full read DTO list (if backend returns more fields)
    getAll: async (): Promise<CategoryReadDTO[]> => {
        const data = await api.get<any[]>(`/catalog/api/categories`);
        return (data || []).map(toRead);
    },

    getById: async (id: number): Promise<CategoryReadDTO> => {
  const urls = [
    `/catalog/api/categories(${id})`,
    `/catalog/api/categories(CategoryId=${id})`,
    `/catalog/api/categories('${id}')`,
    `/catalog/api/categories/${id}`,
    // query-style fallbacks
    `/catalog/api/categories?CategoryId=${id}`,
    `/catalog/api/categories?id=${id}`,
    `/catalog/api/categories?key=${id}`,
  ];
  let lastErr: any = null;

  for (const u of urls) {
    try {
      console.debug('[CategoryService] trying GET', u);
      const raw = await api.get<any>(u);

      // 🔧 quan trọng: luôn trích xuất theo id nếu có mảng/odata
      const item = _extractItemById(raw, id);
      if (item) {
        console.debug('[CategoryService] success GET', u, item);
        return toRead(item);
      }
      // nếu không tìm thấy trong kết quả, thử URL tiếp theo
    } catch (err: any) {
      lastErr = err;
      if (err?.response?.status === 404) continue;
      throw err;
    }
  }

  // Fallback cuối: GET list rồi tìm local theo id
  try {
    console.debug('[CategoryService] fallback: GET list to locate item', id);
    const list = await api.get<any[]>(`/catalog/api/categories`);
    const found = _extractItemById(list, id);
    if (found) return toRead(found);
  } catch (listErr) {
    lastErr = lastErr || listErr;
  }

  const e: any = new Error('Category GET failed: single-item endpoint not available (tried multiple URL forms and list fallback)');
  e.attempted = urls;
  e.cause = lastErr;
  throw e;
},


    createCategory: async (data: { CategoryName: string; Description?: string }) => {
        // send in server-expected shape (PascalCase) to be safe
        const payload = { CategoryName: data.CategoryName, Description: data.Description };
        return await api.post(`/catalog/api/categories`, payload);
    },

    updateCategory: async (id: number, data: { CategoryName?: string; Description?: string }) => {
        const payload: any = {};
        if (data.CategoryName !== undefined) payload.CategoryName = data.CategoryName;
        if (data.Description !== undefined) payload.Description = data.Description;
        const urls = [
            `/catalog/api/categories(${id})`,
            `/catalog/api/categories(CategoryId=${id})`,
            `/catalog/api/categories('${id}')`,
            `/catalog/api/categories/${id}`,
            `/catalog/api/categories?CategoryId=${id}`,
            `/catalog/api/categories?id=${id}`,
            `/catalog/api/categories?key=${id}`,
        ];
        let lastErr: any = null;
        for (const u of urls) {
            try {
                console.debug('[CategoryService] trying PUT', u, payload);
                const resp = await api.put(u, payload);
                console.debug('[CategoryService] success PUT', u);
                return resp;
            } catch (err: any) {
                lastErr = err;
                if (err?.response?.status === 404) continue;
                throw err;
            }
        }
        const e: any = new Error('Category PUT failed');
        e.attempted = urls;
        e.cause = lastErr;
        throw e;
    },

    deleteCategory: async (id: number) => {
        const urls = [
            `/catalog/api/categories/(${id})`
        ];
        let lastErr: any = null;
        for (const u of urls) {
            try {
                console.debug('[CategoryService] trying DELETE', u);
                const resp = await api.delete(u);
                console.debug('[CategoryService] success DELETE', u);
                return resp;
            } catch (err: any) {
                lastErr = err;
                if (err?.response?.status === 404) continue;
                throw err;
            }
        }
        const e: any = new Error('Category DELETE failed: single-item endpoint not available (tried multiple URL forms)');
        e.attempted = urls;
        e.cause = lastErr;
        // attach HTTP-level debug info if available
        e.status = lastErr?.response?.status;
        e.responseHeaders = lastErr?.response?.headers;
        e.responseData = lastErr?.response?.data;
        throw e;
    },
    // --- Admin variants (call admin-specific endpoints when backend exposes them)
    getAdminList: async (params?: { select?: string[]; filter?: any; top?: number; skip?: number }) => {
        const qs = params ? buildQuery(params) : "";
        const res = await api.get<any>(`/catalog/odata/categories${qs}`);
        const items = (res?.value || []).map((it: any) => toRead(it));
        const pageSize = params?.top ?? 10;
        const page = params?.skip ? Math.floor((params.skip as number) / pageSize) + 1 : 1;
        return { items, totalCount: res?.["@odata.count"] ?? 0, page, pageSize };
    },

    getAdminItem: async (id: number) => {
  const attempted: string[] = [];
  let lastErr: any = null;

  // Ưu tiên query-style (do endpoint list đang hoạt động ổn)
  const queryUrl = `/catalog/api/categories?CategoryId=${id}`;
  attempted.push(queryUrl);
  try {
    console.debug('[CategoryService] trying fallback GET', queryUrl);
    const raw = await api.get<any>(queryUrl);
    const item = _extractItemById(raw, id); // 🔧 lọc theo id
    if (item) return toRead(item);
  } catch (err: any) {
    lastErr = lastErr || err;
    if (err?.response?.status !== 404) throw err;
  }

  // Thử admin per-item
  const adminUrl = `/catalog/api/categories/admin/(${id})`;
  attempted.push(adminUrl);
  try {
    console.debug('[CategoryService] trying GET admin item', adminUrl);
    const raw = await api.get<any>(adminUrl);
    const item = _extractItemById(raw, id); // 🔧 lọc theo id
    if (item) return toRead(item);
  } catch (err: any) {
    lastErr = lastErr || err;
    if (err?.response?.status !== 404) throw err;
  }

  // Fallback: GET list rồi tìm local
  try {
    console.debug('[CategoryService] fallback: GET list to locate admin item', id);
    const list = await api.get<any[]>(`/catalog/api/categories`);
    const found = _extractItemById(list, id); // 🔧 lọc theo id
    if (found) return toRead(found);
  } catch (listErr) {
    lastErr = lastErr || listErr;
  }

  const e: any = new Error('Admin Category GET failed: single-item admin endpoint not available (tried admin and fallback forms)');
  e.attempted = attempted;
  e.cause = lastErr;
  throw e;
},


    updateAdmin: async (id: number, data: { CategoryName?: string; Description?: string }) => {
        const payload: any = {};
        if (data.CategoryName !== undefined) payload.CategoryName = data.CategoryName;
        if (data.Description !== undefined) payload.Description = data.Description;
        const res = await api.put(`/catalog/api/categories/admin/(${id})`, payload);
        return res;
    },

    deleteAdmin: async (id: number) => {
        const res = await api.delete(`/catalog/api/categories/admin/(${id})`);
        return res;
    },
};

const _getCandidateId = (it: any) => it?.CategoryId ?? it?.categoryId ?? it?.id ?? undefined;

const _extractItemById = (raw: any, id?: number) => {
    let item: any = raw;
    if (item && typeof item === 'object') {
        if ('data' in item && item.data !== undefined) item = item.data;
        else if ('value' in item && Array.isArray(item.value)) {
            if (id !== undefined) return item.value.find((el: any) => Number(_getCandidateId(el)) === Number(id));
            return item.value.length > 0 ? item.value[0] : undefined;
        }
    }
    if (Array.isArray(item)) {
        if (id !== undefined) return item.find((el: any) => Number(_getCandidateId(el)) === Number(id));
        return item[0];
    }
    return item;
};